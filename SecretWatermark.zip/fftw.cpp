#include <stdint.h>
#include <xnl.h>


XNLEXPORT void * XI_CDECL alloc_complex(xint size){
	
	
	
}

XNLEXPORT void XI_CDECL free_complex(void * p){
	
	
	
}

XNLEXPORT void XI_CDECL fill_complex_double(void * p, xint offset, xint size, xint eoffset, xptr rnp){
	
	
	
}

XNLEXPORT void XI_CDECL fill_complex_double2(void * p, xint offset, xint size, xint eoffset, xptr rnp, xptr inp){
	
	
	
}

XNLEXPORT void XI_CDECL extract_complex_double(void * p, xint offset, xint size, xint eoffset, xptr rnp){
	
	
	
}

XNLEXPORT void XI_CDECL extract_complex_double2(void * p, xint offset, xint size, xint eoffset, xptr rnp, xptr inp){
	
	
	
}

XNLEXPORT double XI_CDECL get_complex_double(void * p, xint index, xbool bi){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_dft_3d(xint n0, xint n1, xint n2, void * in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_dft_2d(xint n0, xint n1, void * in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_dft_1d(xint n, void * in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_c2r_1d(xint n, void * in, xptr out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_r2c_1d(xint n, xptr in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_c2r_2d(xint n0, xint n1, void * in, xptr out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_r2c_2d(xint n0, xint n1, xptr in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_c2r_3d(xint n0, xint n1, xint n2, void * in, xptr out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void * XI_CDECL create_fftw_plan_r2c_3d(xint n0, xint n1, xint n2, xptr in, void * out, xint sign, xint flag){
	
	
	
}

XNLEXPORT void XI_CDECL execute_fftw(void * p){
	
	
	
}

XNLEXPORT void XI_CDECL free_plan(void * p){
	
	
	
}

